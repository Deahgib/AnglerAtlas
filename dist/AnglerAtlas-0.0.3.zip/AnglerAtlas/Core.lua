



local function init()
    
    AnglerAtlas:loadPlayerData()
    AnglerAtlas.UI:Build()
    AnglerAtlas:SelectFish(nil)
    -- AnglerAtlas.UI:Show()
end

init()

