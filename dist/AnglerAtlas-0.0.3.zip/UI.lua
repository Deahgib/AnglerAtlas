-- Create addon interface options tab for AnglerAtlas settings
-- local panel = CreateFrame("Frame")
-- panel.name = "AnglerAtlas"               -- see panel fields
-- InterfaceOptions_AddCategory(panel)  -- see InterfaceOptions API

-- -- add widgets to the panel as desired
-- local title = panel:CreateFontString("ARTWORK", nil, "GameFontNormalLarge")
-- title:SetPoint("TOP")
-- title:SetText("AnglerAtlas")
