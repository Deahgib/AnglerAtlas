local UI = CreateFrame("FRAME", "angler-root", UIParent, "BasicFrameTemplate")

AnglerAtlas.MM:RegisterModule("UI", UI)

AnglerAtlas.UI = UI
